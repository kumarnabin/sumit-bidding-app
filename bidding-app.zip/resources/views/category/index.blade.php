@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Category') }}
                        <ul class="nav justify-content-end">
                            <li class="nav-item">
                                <a class="float-left nav-link " href="{{ route('categories.create') }}">Add</a>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <table class="table table-responsive caption-top">
                            <caption>List of categories</caption>
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($categories as $key=>$category)
                                <tr>
                                    <th scope="row">{{$key++}}</th>
                                    <td>{{$category->name}}</td>
                                    <td>
                                        <a href="{{route('categories.edit',$category)}}">Edit</a>
                                        <button onclick="deleteItem('{{route('categories.destroy',$category)}}')">Delete
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
