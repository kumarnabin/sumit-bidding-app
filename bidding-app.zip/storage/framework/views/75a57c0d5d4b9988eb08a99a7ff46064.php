<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Category')); ?>

                        <ul class="nav justify-content-end">
                            <li class="nav-item">
                                <a class="float-left nav-link " href="<?php echo e(route('categories.create')); ?>">Add</a>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <table class="table table-responsive caption-top">
                            <caption>List of categories</caption>
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key++); ?></th>
                                    <td><?php echo e($category->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('categories.edit',$category)); ?>">Edit</a>
                                        <button onclick="deleteItem('<?php echo e(route('categories.destroy',$category)); ?>')">Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\bidding-app\resources\views/category/index.blade.php ENDPATH**/ ?>