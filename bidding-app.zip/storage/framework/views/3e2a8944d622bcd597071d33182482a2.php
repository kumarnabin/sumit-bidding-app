<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Auction')); ?>

                        <ul class="nav justify-content-end">
                            <li class="nav-item">
                                <a class="float-left nav-link " href="<?php echo e(route('categories.create')); ?>">Add</a>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body">
                        <table class="table table-responsive caption-top">
                            <caption>List of auctions</caption>
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">item</th>
                                <th scope="col">By</th>
                                <th scope="col">Price</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key++); ?></th>
                                    <td><?php echo e($auction->item?->name); ?></td>
                                    <td><?php echo e($auction->user?->name); ?></td>
                                    <td><?php echo e($auction->price); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('auctions.edit',$auction)); ?>">Edit</a>
                                        <button onclick="deleteItem('<?php echo e(route('auctions.destroy',$auction)); ?>')">Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\bidding-app\resources\views/auction/index.blade.php ENDPATH**/ ?>